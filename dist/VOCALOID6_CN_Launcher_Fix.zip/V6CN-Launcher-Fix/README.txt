﻿启动器修复包

1. 解压整个文件夹，不要直接在压缩包里运行。
2. 双击 Repair-Launcher.cmd。默认修复截图中的 AppData\Local\VOCALOID6-CN-6.13.3-R1。
3. 看到成功提示后，从桌面上的 VOCALOID6 Chinese 快捷方式启动。
4. 如果提示 VOCALOID6 仍在运行，先正常关闭它；无响应时保存其他工作后重启电脑再试。

Start-Chinese.cmd 必须保留在程序副本内，桌面只放快捷方式。
修复会备份原启动器与安装记录，不清除设置，也不自动结束进程。

如果仍然打不开，请提供程序副本内的 V6CN-launch.log。也可再次运行 Repair-Launcher.cmd，生成最新的 V6CN-startup-diagnostic.txt。日志只在本机生成，分享前检查其中的路径或工程名称。

自定义安装目录：
Repair-Launcher.cmd -InstallDir "D:\V6-CN-Test"

这次修复未在你的电脑上执行；Windows 桌面快捷方式仍需本机确认。

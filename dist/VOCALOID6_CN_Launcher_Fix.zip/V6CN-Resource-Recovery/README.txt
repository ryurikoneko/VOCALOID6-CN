﻿中文资源恢复包

用途：修复 Missing installed file: zh-CN\VOCALOID6.resources.dll。
本包包含编辑器、插件中文资源及启动适配器。

1. 关闭 VOCALOID6 和相关 DAW。
2. 将压缩包全部解压到一个新文件夹。
3. 双击 Repair-Launcher.cmd。
4. 成功后使用桌面 VOCALOID6 Chinese 快捷方式启动。

默认修复：%LOCALAPPDATA%\VOCALOID6-CN-6.13.3-R1
自定义目录：Repair-Launcher.cmd -InstallDir "D:\V6-CN-Test"

工具校验随包文件，补齐缺失资源。已有损坏补丁会先备份，再更新卸载校验记录。原版主体、工程与用户设置不被覆盖。

Start-Chinese.cmd 本体留在程序目录，桌面只放快捷方式。
如果仍然打不开，请提供程序目录中的 V6CN-launch.log 或重新运行修复工具后生成的 V6CN-startup-diagnostic.txt。
